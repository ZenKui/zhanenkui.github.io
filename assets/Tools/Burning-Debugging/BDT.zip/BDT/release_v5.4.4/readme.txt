Note:
   Error happens when BDT is opened, please fix it as the following step 
WIN 32:
   if your PC NOT have msvcr120.dll， Please move msvcr120.dll in the directory "./mevcr120" to "C:\Windows\System32" 

WIN 64:
   if your PC NOT have msvcr120.dll， Please move msvcr120.dll in the directory "./mevcr120" to "C:\Windows\SysWOW64" 