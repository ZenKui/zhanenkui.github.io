1.must be run as administrator
2.must be installed to C:\
