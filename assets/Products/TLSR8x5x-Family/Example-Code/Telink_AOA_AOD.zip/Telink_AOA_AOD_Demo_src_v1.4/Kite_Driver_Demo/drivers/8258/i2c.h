/********************************************************************************************************
 * @file     i2c.h 
 *
 * @brief    This is the header file for TLSR8258
 *
 * @author	 peng.sun@telink-semi.com;
 * @date     May 8, 2018
 *
 * @par      Copyright (c) 2018, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *           The information contained herein is confidential property of Telink
 *           Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *           of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *           Co., Ltd. and the licensee or the terms described here-in. This heading
 *           MUST NOT be removed from this file.
 *
 *           Licensees are granted free, non-transferable use of the information in this
 *           file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 * @par      History:
 * 			 1.initial release(DEC. 26 2018)
 *
 * @version  A001
 *
 *******************************************************************************************************/

#pragma once
#ifndef I2C_H
#define I2C_H
#include "gpio.h"

/**
 *  @brief  select pin as SDA and SCL of i2c
 */
typedef enum {
	I2C_GPIO_GROUP_A3A4,
	I2C_GPIO_GROUP_B6D7,
	I2C_GPIO_GROUP_C0C1,
	I2C_GPIO_GROUP_C2C3,
}I2C_GPIO_GroupTypeDef;


/**
 *  @brief  select i2c slave mode: DMA and MAPPING
 */
typedef enum {
	I2C_SLAVE_DMA = 0,
	I2C_SLAVE_MAP,
}I2C_SlaveMode;


/**
 * @brief This function reset I2C module.
 * @param[in] none
 * @return none
 */
static inline void i2c_reset(void)
{
	reg_rst0 |= FLD_RST0_I2C;
	reg_rst0 &= (~FLD_RST0_I2C);
}

/**
 * @brief This function serves to set id of I2C module.
 * @param[in] id - this id is fixed id for slave device.For master device, this id is set to access different slave devices.
 * @return none
 */
static inline void i2c_set_id(unsigned char SlaveID)
{
    reg_i2c_id	  = SlaveID; //slave address
}

/**
 * @brief This function servers to config i2c data buffer in slave mode.
 * @param[in] pMapBuf - to store the buffer data.
 * @return none
 */
static inline void i2c_set_mapping_buff(unsigned char * pMapBuf)
{
	 reg_i2c_slave_map_addrl  = (unsigned char)(((unsigned int)pMapBuf & 0xff)); //
	 reg_i2c_slave_map_addrm = (unsigned char)(((unsigned int)pMapBuf>>8)&0xff);
	 reg_i2c_slave_map_addrh = 0x04;
}

/**
 * @brief      This function serves to select a pin port for I2C interface.
 * @param[in]  PinGrp - the pin port selected as I2C interface pin port.
 * @return     none
 */
void i2c_set_pin(I2C_GPIO_GroupTypeDef i2c_pin_group);


/**
 * @brief      This function serves to set the id of slave device and the speed of I2C interface
 *             note: the param ID contain the bit of writting or reading.
 *             eg:the parameter 0x5C. the reading will be 0x5D and writting 0x5C.
 * @param[in]  SlaveID - the id of slave device.it contains write or read bit,the lsb is write or read bit.
 *                       ID|0x01 indicate read. ID&0xfe indicate write.
 * @param[in]  DivClock - the division factor of I2C clock,
 *             I2C clock = System clock / (4*DivClock);if the datasheet you look at is 2*,pls modify it.
 * @return     none
 */
void i2c_master_init(unsigned char SlaveID, unsigned char DivClock);


/**
 *  @brief      This function serves to set the ID and mode of slave device.
 *  @param[in]  device_ID - it contains write or read bit,the lsb is write or read bit.
 *              ID|0x01 indicate read. ID&0xfe indicate write.
 *  @param[in]  mode - set slave mode. slave has two modes, one is DMA mode, the other is MAPPING mode.
 *  @param[in]  pBuf - if slave mode is MAPPING, set the first address of buffer master write or read slave.
 *  @return     none
 */
void i2c_slave_init(unsigned char device_ID,I2C_SlaveMode mode,unsigned char * pMapBuf);


/**
 * @brief      This function serves to write one byte to the slave device at the specified address
 * @param[in]  Addr - i2c slave address where the one byte data will be written
 * @param[in]  AddrLen - length in byte of the address, which makes this function is
 *             compatible for slave device with both one-byte address and two-byte address
 * @param[in]  Data - the one byte data will be written via I2C interface
 * @return     none
 */
void i2c_dma_write_byte(unsigned int Addr, unsigned int AddrLen, unsigned char Data);

/**
 * @brief      This function serves to read one byte from the slave device at the specified address
 * @param[in]  Addr - i2c slave address where the one byte data will be read
 * @param[in]  AddrLen - length in byte of the address, which makes this function is
 *             compatible for slave device with both one-byte address and two-byte address
 * @return     the one byte data read from the slave device via I2C interface
 */
unsigned char i2c_dma_read_byte(unsigned int Addr, unsigned int AddrLen);

/**
 *  @brief      This function serves to write a packet of data to the specified address of slave device
 *  @param[in]  Addr - the register that master write data to slave in. support one byte and two bytes. i.e param2 AddrLen may be 1 or 2.
 *  @param[in]  AddrLen - the length of register. enum 0 or 1 or 2 or 3. based on the spec of i2c slave.
 *  @param[in]  dataBuf - the first SRAM buffer address to write data to slave in.
 *  @param[in]  dataLen - the length of data master write to slave.
 *  @return     none
 */
void i2c_dma_write_buff(unsigned int Addr, unsigned int AddrLen, unsigned char * dataBuf, int dataLen);

/**
 * @brief      This function serves to read a packet of data from the specified address of slave device
 * @param[in]  Addr - the register master read data from slave in. support one byte and two bytes.
 * @param[in]  AddrLen - the length of register. enum 0 or 1 or 2 or 3 based on the spec of i2c slave.
 * @param[in]  dataBuf - the first address of SRAM buffer master store data in.
 * @param[in]  dataLen - the length of data master read from slave.
 * @return     none.
 */
void i2c_dma_read_buff(unsigned int Addr, unsigned int AddrLen, unsigned char * dataBuf, int dataLen);

/**
 *  @brief      This function serves to write a packet of data to slave device working in mapping mode
 *  @param[in]  dataBuf - the first SRAM buffer address to write data to slave in.
 *  @param[in]  dataLen - the length of data master write to slave.
 *  @return     none
 */
void i2c_map_write_buff(unsigned char * dataBuf, int dataLen);

/**
 * @brief      This function serves to read a packet of data from slave device working in mapping mode
 * @param[in]  dataBuf - the first address of SRAM buffer master store data in.
 * @param[in]  dataLen - the length of data master read from slave.
 * @return     none.
 */
void i2c_map_read_buff(unsigned char * dataBuf, int dataLen);


#endif

/** \defgroup GP6  I2C Examples
 *
 * 	@{
 */
/*! \page i2c Table of Contents
	- [API-I2C-CASE1:I2C DMA MASTER MODE](#I2C_DMA_MASTER_MODE)
    - [API-I2C-CASE2:I2C DMA SLAVE MODE](#I2C_DMA_SLAVE_MODE)
	- [API-I2C-CASE3:I2C MAP MASTER MODE](#I2C_MAP_MASTER_MODE)
    - [API-I2C-CASE4:I2C MAP SLAVE MODE](#I2C_MAP_SLAVE_MODE)

<h1 id=I2C_DMA_MASTER_MODE> API-I2C-CASE1:I2C DMA MASTER MODE </h1>

| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | None ||| Interrupt handler function [**Mandatory**] | 2019-1-10 |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | i2c_set_pin()|i2c_set_pin(I2C_GPIO_GROUP_C0C1) | Initialize i2c pin| ^ |
| ^ | ^ |i2c_master_init()|i2c_master_init(0x5C, (unsigned char)(CLOCK_SYS_CLOCK_HZ/(4*I2C_CLK_SPEED)) )|Set the id of slave device and the speed of I2C interface | ^ |
| ^ | main_loop()|i2c_dma_write_buff()|i2c_dma_write_buff(SLAVE_DEVICE_ADDR, SLAVE_DEVICE_ADDR_LEN, (unsigned char *)i2c_tx_buff, BUFF_DATA_LEN)| Write a packet of data to the specified address of slave device| ^ |
| ^ |^ |i2c_dma_read_buff()|i2c_dma_read_buff(SLAVE_DEVICE_ADDR,  SLAVE_DEVICE_ADDR_LEN, (unsigned char *)i2c_rx_buff, BUFF_DATA_LEN)| Read data from slave device | ^ |

Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}
#define     BUFF_DATA_LEN				16
#define     SLAVE_DEVICE_ADDR			0x48000
#define     SLAVE_DEVICE_ADDR_LEN		3
#define     I2C_CLK_SPEED				200000
volatile unsigned char i2c_tx_buff[BUFF_DATA_LEN] = {0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff};
volatile unsigned char i2c_rx_buff[BUFF_DATA_LEN] = {0};
~~~~~~~~~~~~~~~~~~~~~~~~~~~	

<h1 id=I2C_DMA_SLAVE_MODE> API-I2C-CASE2:I2C DMA SLAVE MODE </h1>

| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | if(reg_i2c_slave_irq_status & FLD_HOST_CMD_IRQ==FLD_HOST_CMD_IRQ) ||| I2c interrupt status | 2019-1-10 |
| ^ | >reg_i2c_slave_irq_status &Iota;= FLD_HOST_CMD_IRQ ||| clear irq status | ^ |
| ^ | >i2c_irq_cnt ++||| Interrupt processing function | ^ |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | i2c_set_pin()|i2c_set_pin(I2C_GPIO_GROUP_C0C1) | Initialize i2c pin| ^ |
| ^ | ^ |i2c_slave_init()|i2c_slave_init(0x5C, I2C_SLAVE_DMA, NULL)|Set the ID and mode of slave device | ^ |
| ^ | ^ |reg_irq_mask &Iota;= FLD_IRQ_MIX_CMD_EN || I2c interrupt enable | ^ |
| ^ | main_loop() | None || Main program loop | ^ |

\n
Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}
unsigned char  i2c_irq_cnt=0;
~~~~~~~~~~~~~~~~~~~~~~~~~~~	

<h1 id=I2C_MAP_MASTER_MODE> API-I2C-CASE3:I2C MAP MASTER MODE </h1>

| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | none |||  Interrupt handler function | 2019-1-10 |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | i2c_set_pin()|i2c_set_pin(I2C_GPIO_GROUP_C0C1) | Initialize i2c pin| ^ |
| ^ | ^ |i2c_master_init()|i2c_master_init(0x5C, (unsigned char)(CLOCK_SYS_CLOCK_HZ/(4*I2C_CLK_SPEED)) )|Set the id of slave device and the speed of I2C interface | ^ |
| ^ | main_loop()|i2c_map_write_buff()|i2c_map_write_buff((unsigned char*)i2c_tx_buff, BUFF_DATA_LEN)| Write a packet of data to slave device working in mapping mode| ^ |
| ^ | ^ |i2c_map_read_buff()|i2c_map_read_buff((unsigned char*)i2c_rx_buff, BUFF_DATA_LEN)|Read a packet of data from slave device working in mapping mode| ^ |


\n
Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}
#define     BUFF_DATA_LEN				64
#define     I2C_CLK_SPEED				200000
volatile unsigned char i2c_tx_buff[BUFF_DATA_LEN] = {0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff};
volatile unsigned char i2c_rx_buff[BUFF_DATA_LEN] = {0};

~~~~~~~~~~~~~~~~~~~~~~~~~~~	

<h1 id=I2C_MAP_SLAVE_MODE> API-I2C-CASE4:I2C MAP SLAVE MODE </h1>

| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | if(reg_i2c_slave_irq_status & FLD_HOST_CMD_IRQ ==FLD_HOST_CMD_IRQ) ||| I2c interrupt status | 2019-1-10 |
| ^ | >reg_i2c_slave_irq_status &Iota;= FLD_HOST_CMD_IRQ ||| clear  irq status | ^ |
| ^ | >i2c_irq_cnt ++ |||Interrupt processing function | ^ |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | i2c_set_pin()|i2c_set_pin(I2C_GPIO_GROUP_C0C1) | Initialize i2c pin| ^ |
| ^ | ^ |i2c_slave_init()|i2c_slave_init(0x5C, I2C_SLAVE_MAP, (unsigned char *)i2c_slave_mapping_buff+64)|Set the ID and mode of slave device | ^ |
| ^ | ^ |reg_irq_mask &Iota;= FLD_IRQ_MIX_CMD_EN || I2c interrupt enable | ^ |
| ^ | main_loop() | None || Main program loop | ^ |


\n
Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}

__attribute__((aligned(128))) unsigned char i2c_slave_mapping_buff[128] = {0};
unsigned char  i2c_irq_cnt=0;

~~~~~~~~~~~~~~~~~~~~~~~~~~~	

<h1> History Record </h1>

| Date | Description | Author |
| :--- | :---------- | :----- |
| 2019-1-10 | initial release | SP/LJW |

*/

 /** @}*/ //end of GP6
