/********************************************************************************************************
 * @file     audio.c
 *
 * @brief    This is the Audio driver file for TLSR8258
 *
 * @author   junyuan.zhang@telink-semi.com;junwei.lu@telink-semi.com
 * @date     May 8, 2018
 *
 * @par      Copyright (c) 2018, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *           The information contained herein is confidential property of Telink
 *           Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *           of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *           Co., Ltd. and the licensee or the terms described here-in. This heading
 *           MUST NOT be removed from this file.
 *
 *           Licensees are granted free, non-transferable use of the information in this
 *           file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 * @par      History:
 * 			 1.initial release(DEC. 26 2018)
 *
 * @version  A001
 *
 *******************************************************************************************************/

#include "audio.h"
#include "pga.h"
#include "adc.h"
#include "irq.h"
#include "register.h"
#include "usb.h"


unsigned char AMIC_ADC_SampleLength[3] = {0xf0/*96K*/,0xab/*132K*/,0x75/*192K*/};

unsigned char DMIC_CLK_Mode[RATE_SIZE] = {47/*8	k	1021.277*/,	47/*16k	1021.277*/,
										  34/*22k	1411.765*/,	47/*32k	1021.277*/,
										  34/*44k	1411.765*/,	32/*48k	1500	*/,
										  32/*96k	1500	*/};

unsigned char DMIC_CIC_Rate[RATE_SIZE] = {0x23/*8k 7.978723		CIC_MODE 0*/,	0x22/*16k 15.95745	CIC_MODE 0*/,
										  0x32/*22k 22.05882	CIC_MODE 0*/,	0x11/*32k 31.91489	CIC_MODE 0*/,
										  0x11/*44k 44.11765	CIC_MODE 0*/,	0x11/*48k 46.875	CIC_MODE 0*/,
										  0x00/*96k 93.75 		CIC_MODE 0*/};

unsigned char AMIC_CIC_Rate[RATE_SIZE] = {0xab/*8k  96/12	*/,	0x32/*16k 96/6	*/,
										  0x85/*22k 132/6	*/,	0x42/*32k 96/3	*/,
										  0x42/*44k 132/3	*/,	0x31/*48k 96/2	*/,
										  0x20/*96k			*/};

/*  matrix used under condition: I2S = 2 MHz  */
unsigned long ASDM_Rate_Matching[RATE_SIZE] = {0x00832001/*8k */,0x01063001/*16k*/,
											   0x01687001/*22k*/,0x020C5001/*32k*/,
											   0x02D4D001/*44k*/,0x03127001/*48k*/,
											   0x0624d001/*96k*/};

/*  matrix used under condition: I2S = 2 MHz  */
unsigned long DSDM_Rate_Matching[RATE_SIZE] = {0x00820001/*8 k*/,0x01058001/*16k*/,
											   0x01697001/*22k*/,0x020AF001/*32k*/,
											   0x02D2E001/*44k*/,0x03000001/*48k*/,
											   0x06000001/*96k*/};


/**
* brief: audio amic initial function. configure ADC corresponding parameters. set hpf,lpf and decimation ratio.
* param[in] mode_flag -- '1' differ mode ; '0' signal end mode
* param[in] misc_sys_tick -- system ticks of adc misc channel.
* param[in] l_sys_tick -- system tick of adc left channel CLOCK_SYS_TYPE
* param[in]  fhs_source - the parameter is CLOCK_SYS_TYPE. avoid CLOCK_SYS_TYPE to be modified to other word.such as SYS_TYPE etc.
* return none
*/
void audio_amic_init(AudioRate_Typedef Audio_Rate)
{

	/*******1.ADC setting for analog audio sample**************************/
	adc_reset();   //reset whole digital adc module
	adc_power_on(1);   //power on sar adc
	adc_clk_en(1);  //enable signal of 24M clock to sar adc


	adc_set_clk_div(5); //adc sample clk= 24M/(1+5)=4M

	//adc state machine state cnt 2( "set" stage and "capture" state for left channel)
	adc_set_max_state_cnt(0x02);

	//set "capture state" length for misc channel: 240
	//set "set state" length for misc channel: 10
	//adc state machine  period  = 24M/250 = 96K
	adc_set_all_set_state_length(10);									//max_s
	if((Audio_Rate == AUDIO_44K)||(Audio_Rate == AUDIO_22K))
	{
		adc_set_left_right_capture_state_length(AMIC_ADC_SampleLength[1]);	//max_c	132K
	}
	else
	{
		adc_set_left_right_capture_state_length(AMIC_ADC_SampleLength[0]);	//max_c	96K
	}
//	adc_set_misc_rns_capture_state_length(0x0a);						//max_mc

	adc_set_chn_en(ADC_LEFT_CHN);    								//left channel enable
	adc_set_all_input_mode(ADC_LEFT_CHN, DIFFERENTIAL_MODE);  				//left channel differential mode
	adc_set_all_differential_p_n_ain(ADC_LEFT_CHN, PGA0P, PGA0N);  //left channel positive and negative data in

	adc_set_all_vref(ADC_LEFT_CHN, ADC_VREF_0P6V);					//left channel vref
//	adc_set_all_vref(ADC_RIGHT_CHN, ADC_VREF_0P6V);
//	adc_set_all_vref(ADC_MISC_CHN, ADC_VREF_0P6V);
	adc_set_all_resolution(ADC_LEFT_CHN, RES14);							//left channel resolution
	adc_set_all_tsample_cycle(ADC_LEFT_CHN, SAMPLING_CYCLES_6);				//left channel tsample

//	adc_set_vref_vbat_div(ADC_VBAT_DIVIDER_OFF);                    //vbat vref divider
	adc_set_all_ain_pre_scaler(ADC_PRESCALER_1);                            //ain pre scaler none

	adc_set_itrim_preamp(ADC_CUR_TRIM_PER100);
	adc_set_itrim_vrefbuf(ADC_CUR_TRIM_PER125);
	adc_set_itrim_vcmbuf(ADC_CUR_TRIM_PER100);


	//PGA0 left  C0/C1 ON,
	//PGA1 right C2/C3 OFF
	analog_write (anareg_fd, MASK_VAL(	FLD_PGA_SEL_VIN_LEFT_P, PGA_AIN_ON, \
													FLD_PGA_SEL_VIN_LEFT_N, PGA_AIN_ON, \
													FLD_PGA_SEL_VIN_RIGHT_P,PGA_AIN_OFF,\
													FLD_PGA_SEL_VIN_RIGHT_N,PGA_AIN_OFF) );

	//
	adc_set_left_boost_bias(ADC_GAIN_STAGE_BIAS_PER75);

	analog_write (anareg_fc, MASK_VAL( FLD_PGA_ITRIM_GAIN_L, ADC_GAIN_STAGE_BIAS_PER150, \
												  FLD_PGA_ITRIM_GAIN_R,ADC_GAIN_STAGE_BIAS_PER150, \
												  FLD_ADC_MODE, 0, \
												  FLD_SAR_ADC_POWER_DOWN, 0, \
												  FLD_POWER_DOWN_PGA_CHN_L, 0, \
												  FLD_POWER_DOWN_PGA_CHN_R, 1) );



	analog_write(0xfe,0x05);					//0xfe default value is 0xe5,for output audio, mast claer 0xfe<7:5>
	reg_pga_fix_value = MASK_VAL(	FLD_PGA_POST_AMPLIFIER_GAIN, PGA_POST_GAIN_0DB,\
									FLD_PGA_PRE_AMPLIFIER_GAIN, PGA_PRE_GAIN_26DB,\
									FLD_PGA_GAIN_FIX_EN, 1);





	////////////////////////////// ALC HPF LPF setting /////////////////////////////////
	//enable hpf, enable lpf, anable alc, disable double_down_sampling
	if(Audio_Rate==AUDIO_32K)
	{
		reg_aud_alc_hpf_lpf_ctrl =   MASK_VAL( FLD_AUD_IN_HPF_SFT,  0x0b,   //different pcb may set different value.
											   FLD_AUD_IN_HPF_BYPASS, 0, \
											   FLD_AUD_IN_ALC_BYPASS, 0, \
											   FLD_AUD_IN_LPF_BYPASS, 0, \
											   FLD_DOUBLE_DOWN_SAMPLING_ON, 0);
	}
	else
	{
		reg_aud_alc_hpf_lpf_ctrl =   MASK_VAL( FLD_AUD_IN_HPF_SFT,  0x0b,   //different pcb may set different value.
											   FLD_AUD_IN_HPF_BYPASS, 0, \
											   FLD_AUD_IN_ALC_BYPASS, 0, \
											   FLD_AUD_IN_LPF_BYPASS, 0, \
											   FLD_DOUBLE_DOWN_SAMPLING_ON, 1);
	}
	//alc mode select digital mode
	reg_aud_alc_cfg &= ~FLD_AUD_ALC_ANALOG_MODE_EN;
	//alc left channel select manual regulate, and set volume
	//A2 Boost Gain 26dB--->18db 
	reg_aud_alc_vol_l_chn = MASK_VAL( FLD_AUD_ALC_MIN_VOLUME_IN_DIGITAL_MODE,  0x25, \
									  FLD_AUD_ALC_DIGITAL_MODE_AUTO_REGULATE_EN, 0);




	//2. Dfifo setting
	reg_clk_en2 |= FLD_CLK2_DFIFO_EN; //enable dfifo clock, this will be initialed in cpu_wakeup_int()
#if AUDIO_DBL_BUF_ENABLE
	reg_dfifo_mode = FLD_AUD_DFIFO1_IN;
#else
	reg_dfifo_mode = FLD_AUD_DFIFO0_IN;
#endif
	//amic input, mono mode, enable decimation filter
	reg_dfifo_ain = 	  MASK_VAL( FLD_AUD_DMIC0_DATA_IN_RISING_EDGE,AUDIO_DMIC_DATA_IN_FALLING_EDGE,\
									FLD_AUD_INPUT_SELECT, AUDIO_INPUT_AMIC, \
									FLD_AUD_INPUT_MONO_MODE, 1, \
									FLD_AUD_DECIMATION_FILTER_BYPASS, 0);


	reg_audio_dec_mode  |= FLD_AUD_LNR_VALID_SEL | FLD_AUD_CIC_MODE;
//	reg_dfifo_dec_ratio = AMIC_CIC_Rate[Audio_Rate];
	reg_dfifo_dec_ratio = 0x42;  // 96k/3 = 32k, down sampling to 16K by set core_b40<7>

}

/**
 * @brief     This function servers to send data to USB.
 * @param[in] Input_type - audio input type.
 * @param[in] Audio_Rate - audio rate.
 * @return    none.
 */
void audio_tx_data_to_usb(AudioInput_Typedef Input_Type,AudioRate_Typedef Audio_Rate)
{

    int i=0;
    signed short data_h,data_l;
    unsigned char length = 0;

    usbhw_reset_ep_ptr(USB_EDP_MIC);

    switch(Audio_Rate)
    {
    case 	AUDIO_8K:		length = 8;break;
    case	AUDIO_16K:		length = 16;break;
    case	AUDIO_22K:		length = 22;break;
    case	AUDIO_32K:		length = 32;break;
    case	AUDIO_44K:		length = 44;break;
    case	AUDIO_48K:		length = 48;break;
    case	AUDIO_96K:		length = 96;break;
    default:				length = 96;break;
    }

    if(Input_Type==DMIC)
    {
		for (i=0; i<length; i++) {
			if(reg_dfifo_irq_status & FLD_AUD_DFIFO0_L_IRQ)
				break;
			if(i%2)
			{
				data_h = reg_usb_mic_dat1;
				reg_usb_ep7_dat = data_h;
				reg_usb_ep7_dat = data_h>>8;
			}
			else{
				data_l = reg_usb_mic_dat0;
				reg_usb_ep7_dat = data_l;
				reg_usb_ep7_dat = data_l>>8;
			}
		}
    }
    else
    {
		for (i=0;i<length; i++)
		{
			if(reg_dfifo_irq_status & FLD_AUD_DFIFO0_L_IRQ)
			{
				if(i%2) {
					reg_usb_ep7_dat = data_l;
					reg_usb_ep7_dat = data_l>>8;
				}
				else{
					reg_usb_ep7_dat = data_h;
					reg_usb_ep7_dat = data_h>>8;
				}
			}
			else
			{
				if(i%2)
				{
					data_l = reg_usb_mic_dat1;
					reg_usb_ep7_dat = data_l;
					reg_usb_ep7_dat = data_l>>8;
				}
				else
				{
					data_h = reg_usb_mic_dat0;
					reg_usb_ep7_dat = data_h;
					reg_usb_ep7_dat = data_h>>8;
				}
			}
		}
    }
	reg_usb_ep7_ctrl = FLD_USB_EP_BUSY;
}

/**
 * @brief     This function servers to set USB Input.
 * @param[in] none
 * @return    none.
 */
void audio_rx_data_from_usb(void)
{

	unsigned char len = reg_usb_ep6_ptr;
	usbhw_reset_ep_ptr(USB_EDP_SPEAKER);

	signed short data;

	for (int i=0; i<len; i+=2)
	{
		if(i%4)
		{
			data = reg_usb_ep6_dat & 0xff;
			data |= reg_usb_ep6_dat << 8;
			reg_usb_mic_dat0 = data;
		}
		else
		{
			data = reg_usb_ep6_dat & 0xff;
			data |= reg_usb_ep6_dat << 8;
			reg_usb_mic_dat1 = data;
		}
	}
	reg_usb_ep6_ctrl = FLD_USB_EP_BUSY;
}
/**
 * @brief     This function servers to receive data from buffer.
 * @param[in] buf - the buffer in which the data need to write
 * @param[in] len - the length of the buffer.
 * @return    none.
 */
void audio_rx_data_from_buff(signed char* buf,unsigned int len)
{
	signed short data;

	for (int i=0; i<len; i+=2)
	{
		if(i%4)
		{
			data = buf[i] & 0xff;
			data |= buf[i+1] << 8;
			reg_usb_mic_dat0 = data;
		}
		else
		{
			data = buf[i] & 0xff;
			data |= buf[i+1] << 8;
			reg_usb_mic_dat1 = data;
		}
	}
}

/**
 * @brief     audio DMIC init function, config the speed of DMIC and downsample audio data to required speed.
 *            actually audio data is dmic_speed/d_samp.
 * @param[in] Audio_Rate  - audio rate.
 * @return    none.
 */
void audio_dmic_init(AudioRate_Typedef Audio_Rate)
{
	//1. Dfifo setting
	reg_clk_en2 |= FLD_CLK2_DFIFO_EN; //enable dfifo clock, this will be initialed in cpu_wakeup_int()
	reg_dfifo_mode = FLD_AUD_DFIFO0_IN | FLD_AUD_DFIFO0_L_INT;

	//2. amic input, mono mode, enable decimation filter
	reg_dfifo_ain = 	  MASK_VAL( FLD_AUD_DMIC0_DATA_IN_RISING_EDGE,	AUDIO_DMIC_DATA_IN_RISING_EDGE,\
									FLD_AUD_INPUT_SELECT, 				AUDIO_INPUT_DMIC, \
									FLD_AUD_INPUT_MONO_MODE, 			1, \
									FLD_AUD_DECIMATION_FILTER_BYPASS, 	0, \
									FLD_AUD_DMIC_RISING_EDGE_BYPASS  ,	0, \
									FLD_AUD_DMIC_FALLING_EDGE_BYPASS ,	0);

	reg_dfifo_dec_ratio = 0x3a;

	////////////////////////////// ALC HPF LPF setting /////////////////////////////////
	//enable hpf, enable lpf, anable alc, disable double_down_sampling
	reg_aud_alc_hpf_lpf_ctrl =   MASK_VAL( FLD_AUD_IN_HPF_SFT,  0x0b,   //different pcb may set different value.
										   FLD_AUD_IN_HPF_BYPASS, 0, \
										   FLD_AUD_IN_ALC_BYPASS, 1, \
										   FLD_AUD_IN_LPF_BYPASS, 1, \
										   FLD_DOUBLE_DOWN_SAMPLING_ON, 1);
	/*******1.Dmic setting for audio input**************************/
	reg_audio_ctrl = AUDIO_OUTPUT_OFF;

	audio_set_dmic_clk(0x8a,0xea);     //16K*2*64=2.048M,

}

/**
 * @brief     audio USB init function, config the speed of DMIC and downsample audio data to required speed.
 *            actually audio data is dmic_speed/d_samp.
 * @param[in] Audio_Rate  - audio rate.
 * @return    none.
 */
void audio_usb_init(AudioRate_Typedef Audio_Rate)
{
	//1. Dfifo setting
	reg_clk_en2 |= FLD_CLK2_DFIFO_EN; //enable dfifo clock, this will be initialed in cpu_wakeup_int()
	reg_dfifo_mode = FLD_AUD_DFIFO0_IN | FLD_AUD_DFIFO0_L_INT;

	//2. amic input, mono mode, enable decimation filter
	reg_dfifo_ain = 	  MASK_VAL( FLD_AUD_DMIC0_DATA_IN_RISING_EDGE,	AUDIO_DMIC_DATA_IN_RISING_EDGE,\
									FLD_AUD_INPUT_SELECT, 				AUDIO_INPUT_USB, \
									FLD_AUD_INPUT_MONO_MODE, 			0, \
									FLD_AUD_DECIMATION_FILTER_BYPASS, 	1, \
									FLD_AUD_DMIC_RISING_EDGE_BYPASS  ,	0, \
									FLD_AUD_DMIC_FALLING_EDGE_BYPASS ,	0);

	reg_dfifo_dec_ratio = 0x00;

	////////////////////////////// ALC HPF LPF setting /////////////////////////////////
	//enable hpf, enable lpf, anable alc, disable double_down_sampling
	reg_aud_alc_hpf_lpf_ctrl =   MASK_VAL( FLD_AUD_IN_HPF_SFT,  0x0b,   //different pcb may set different value.
										   FLD_AUD_IN_HPF_BYPASS, 1, \
										   FLD_AUD_IN_ALC_BYPASS, 1, \
										   FLD_AUD_IN_LPF_BYPASS, 1, \
										   FLD_DOUBLE_DOWN_SAMPLING_ON, 0);
	/*******1.Dmic setting for audio input**************************/
	reg_audio_ctrl = AUDIO_OUTPUT_OFF;

	reg_pga_fix_value = MASK_VAL(	FLD_PGA_POST_AMPLIFIER_GAIN, PGA_POST_GAIN_0DB,\
										FLD_PGA_PRE_AMPLIFIER_GAIN, PGA_PRE_GAIN_26DB,\
										FLD_PGA_GAIN_FIX_EN, 0);

	audio_set_dmic_clk(0x81,0x18);     //16K*2*64=2.048M,

}

/**
 * @brief     audio buff init function, config the speed of DMIC and downsample audio data to required speed.
 *            actually audio data is dmic_speed/d_samp.
 * @param[in] Audio_Rate  - audio rate.
 * @return    none.
 */
void audio_buff_init(AudioRate_Typedef Audio_Rate)
{
	//1. Dfifo setting
	reg_clk_en2 |= FLD_CLK2_DFIFO_EN; //enable dfifo clock, this will be initialed in cpu_wakeup_int()
	reg_dfifo_mode = FLD_AUD_DFIFO0_IN | FLD_AUD_DFIFO0_L_INT;

	//2. amic input, mono mode, enable decimation filter
	reg_dfifo_ain = 	  MASK_VAL( FLD_AUD_DMIC0_DATA_IN_RISING_EDGE,	AUDIO_DMIC_DATA_IN_RISING_EDGE,\
									FLD_AUD_INPUT_SELECT, 				AUDIO_INPUT_USB, \
									FLD_AUD_INPUT_MONO_MODE, 			0, \
									FLD_AUD_DECIMATION_FILTER_BYPASS, 	1, \
									FLD_AUD_DMIC_RISING_EDGE_BYPASS  ,	0, \
									FLD_AUD_DMIC_FALLING_EDGE_BYPASS ,	0);

	reg_dfifo_dec_ratio = 0x00;

	////////////////////////////// ALC HPF LPF setting /////////////////////////////////
	//enable hpf, enable lpf, anable alc, disable double_down_sampling
	reg_aud_alc_hpf_lpf_ctrl =   MASK_VAL( FLD_AUD_IN_HPF_SFT,  0x0b,   //different pcb may set different value.
										   FLD_AUD_IN_HPF_BYPASS, 1, \
										   FLD_AUD_IN_ALC_BYPASS, 1, \
										   FLD_AUD_IN_LPF_BYPASS, 1, \
										   FLD_DOUBLE_DOWN_SAMPLING_ON, 0);
	/*******1.Dmic setting for audio input**************************/
	reg_audio_ctrl = AUDIO_OUTPUT_OFF;

	reg_pga_fix_value = MASK_VAL(	FLD_PGA_POST_AMPLIFIER_GAIN, PGA_POST_GAIN_0DB,\
										FLD_PGA_PRE_AMPLIFIER_GAIN, PGA_PRE_GAIN_26DB,\
										FLD_PGA_GAIN_FIX_EN, 0);

	audio_set_dmic_clk(0x81,0x18);     //16K*2*64=2.048M,

}

 /**
 *
 *	@brief	   sdm setting function, enable or disable the sdm output, configure SDM output paramaters
 *
  *	@param[in]	InType -	  SDM input type, such as AMIC,DMIC,I2S_IN,USB_IN.
 *	@param[in]	Audio_Rate - audio sampling rate, such as 16K,32k etc.
 *	@param[in]	audio_out_en - audio output enable or disable set, '1' enable audio output; '0' disable output
 *
 *	@return	none
 */
void audio_set_sdm_output(AudioInput_Typedef InType,AudioRate_Typedef Audio_Rate,unsigned char audio_out_en)
{
	if(audio_out_en)
	{
		//SDM0  EVB(C1T139A30_V1.2) not used
//		gpio_set_func(GPIO_PB4, AS_SDM);
//		gpio_set_func(GPIO_PB5, AS_SDM);
		//SDM1
		gpio_set_func(GPIO_PB6, AS_SDM);
		gpio_set_func(GPIO_PB7, AS_SDM);

		reg_pwm_ctrl = MASK_VAL( 	FLD_PWM_MULTIPLY2,			0,\
									FLD_PWM_ENABLE,				0,\
									FLD_LINER_INTERPOLATE_EN,	1,\
									FLD_LEFT_SHAPING_EN,		0,\
									FLD_RIGTH_SHAPING_EN,		0);

		reg_pn2_right &= SDM_LEFT_CHN_CONST_EN;		//enable pn

		audio_set_i2s_clk(1,24);

		reg_ascl_tune = ASDM_Rate_Matching[Audio_Rate];


		reg_pn1_left =	MASK_VAL( 	PN1_LEFT_CHN_BITS,		6,\
									PN2_LEFT_CHN_EN, 		0,\
									PN1_LEFT_CHN_EN, 		0);
		reg_pn2_left =	MASK_VAL( 	PN2_LEFT_CHN_BITS,		6,\
									PN2_RIGHT_CHN_EN, 		0,\
									PN1_RIGHT_CHN_EN, 		0);
		reg_pn1_right =	MASK_VAL( 	PN1_RIGHT_CHN_BITS,		6,\
									CLK2A_AUDIO_CLK_EN, 	0,\
									EXCHANGE_SDM_DATA_EN,	0);
		reg_pn2_right = MASK_VAL( 	PN2_RIGHT_CHN_BITS,		6,\
									SDM_LEFT_CHN_CONST_EN, 	0,\
									SDM_RIGHT_CHN_CONST_EN, 0);

		reg_dfifo_mode |= FLD_AUD_DFIFO0_OUT;

		//config player mode
		if(InType == I2S_IN)
		{
			reg_audio_ctrl = (FLD_AUDIO_MONO_MODE|FLD_AUDIO_SDM_PLAYER_EN|FLD_AUDIO_I2S_RECORDER_EN|FLD_AUDIO_I2S_INTERFACE_EN);
		}
		else if(InType == USB_IN)
		{
			reg_audio_ctrl = (FLD_AUDIO_SDM_PLAYER_EN|FLD_AUDIO_HPF_EN);
		}
		else
		{
			if((Audio_Rate==AUDIO_16K) && (InType==BUF_IN))
			{
				reg_audio_ctrl = (FLD_AUDIO_MONO_MODE|FLD_AUDIO_SDM_PLAYER_EN);
			}
			else
			{
				reg_audio_ctrl = (FLD_AUDIO_SDM_PLAYER_EN);
			}
		}
	}
	else
	{
		reg_audio_ctrl = AUDIO_OUTPUT_OFF;
	}
}

/*
*	The software control interface may be operated using either a 3-wire (SPI-compatible) or 2-wire MPU
*	interface. Selection of interface format is achieved by setting the state of the MODE pin.
*		MODE	0	2 wire		default(hardware)
*				1	3 wire
*	In 2-wire mode, the state of CSB pin allows the user to select one of two addresses.
*		CSB		0	0011010		default(hardware)
*				1   0011011
*
*	note:
*		The WM8731 is not a standard I2C interface, so the Kite standard I2C driver is not used.
*/

#define		WM8731_LEFT_IN						0x00		//Left Line In
#define		WM8731_RIGHT_IN						0x02		//Right Line In
#define		WM8731_LEFT_HEADPHONE_OUT			0x04		//Left Headphone Out
#define		WM8731_RIGHT_HEADPHONE_OUT			0x06		//Right Headphone Out

#define		WM8731_ANA_AUDIO_PATH_CTRL			0x08		//Analogue Audio Path Control
#define		WM8731_DIG_AUDIO_PATH_CTRL			0x0a		//Digital Audio Path Control
#define		WM8731_POWER_DOWN_CTRL				0x0c		//Power Down Control
#define		WM8731_DIG_AUDIO_INTERFACE_FORMAT	0x0e		//Digital Audio Interface Format
#define		WM8731_SAMPLING_CTRL 				0x10		//Sampling Control
#define		WM8731_ACTIVE_CTRL 					0x12		//Active Control
#define		WM8731_RESET_CTRL 					0x1e		//Reset Register

unsigned char LineIn_To_I2S_CMD_TAB[9][2]={	{WM8731_RESET_CTRL, 				0x00},
											{WM8731_LEFT_IN,					0x17},
											{WM8731_RIGHT_IN,					0x17},
											{WM8731_ANA_AUDIO_PATH_CTRL,		0x02},
											{WM8731_DIG_AUDIO_PATH_CTRL,		0x09},
											{WM8731_POWER_DOWN_CTRL,			0x0a},
											{WM8731_DIG_AUDIO_INTERFACE_FORMAT,	0x02},
											{WM8731_SAMPLING_CTRL,				0x18},
											{WM8731_ACTIVE_CTRL,				0x01},
};

unsigned char I2S_To_HPout_CMD_TAB[7][2] ={	{WM8731_RESET_CTRL, 				0x00},
											{WM8731_ANA_AUDIO_PATH_CTRL,		0x12},
											{WM8731_DIG_AUDIO_PATH_CTRL,		0x00},
											{WM8731_POWER_DOWN_CTRL,			0x07},
											{WM8731_DIG_AUDIO_INTERFACE_FORMAT,	0x02},
											{WM8731_SAMPLING_CTRL,				0x18},
											{WM8731_ACTIVE_CTRL,				0x01},
};

/**
 * @brief     This function servers to config I2S input.
 * @param[in] i2c_pin_group - select the pin for I2S.
 * @param[in] CodecMode - select I2S mode.
 * @param[in] sysclk - system clock.
 * @return    none.
 */
void audio_set_codec( I2C_GPIO_GroupTypeDef i2c_pin_group , CodecMode_Typedef CodecMode,unsigned sysclk)
{

	unsigned char i = 0;

	//I2C pin set
	i2c_gpio_set(i2c_pin_group);  	//SDA/CK : A3/A4
	i2c_master_init(0x34, (unsigned char)(sysclk/(4*200000)) );		//i2c clock 200K, only master need set i2c clock

	if(CodecMode == CODEC_MODE_LINE_TO_HEADPHONE_LINEOUT_I2S)
	{
		for(i=0;i<9;i++)
		{
			do
			{
				WRITE_REG8(0x04,LineIn_To_I2S_CMD_TAB[i][0]);
				WRITE_REG8(0x05,LineIn_To_I2S_CMD_TAB[i][1]);
				WRITE_REG8(0x07,0x37);
				while(READ_REG8(0x02)&0x01);
			}
			while(READ_REG8(0x02)&0x04);
		}
	}
	else if(CodecMode == CODEC_MODE_I2S_TO_HEADPHONE_LINEOUT)
	{
		for(i=0;i<7;i++)
		{
			do
			{
				WRITE_REG8(0x04,I2S_To_HPout_CMD_TAB[i][0]);
				WRITE_REG8(0x05,I2S_To_HPout_CMD_TAB[i][1]);
				WRITE_REG8(0x07,0x37);
				while(READ_REG8(0x02)&0x01);
			}
			while(READ_REG8(0x02)&0x04);
		}
	}
	else
	{

	}
}

/**
 * @brief     audio I2S init in function, config the speed of i2s and MCLK to required speed.
 * @param[in] none.
 * @return    none.
 */
void audio_i2s_init(void)
{
	/*******1.I2S setting for audio input**************************/
	reg_audio_ctrl = AUDIO_OUTPUT_OFF;

	//config dmic clock for 12Mhz to offer the MCLK of CORDEC
	gpio_set_func(GPIO_PA1, AS_DMIC);		//XTI/MCLK from DMIC clk
	audio_set_dmic_clk(0x81,0x4);

	//config i2s clock for 1Mhz to offer the clk of CORDEC
	gpio_set_func(GPIO_PD7, AS_I2S);		//I2S_BCK
	gpio_set_func(GPIO_PD2, AS_I2S);		//I2S_ADC_LRC  I2S_DAC_LRC
	gpio_set_func(GPIO_PD3, AS_I2S);		//I2S_ADC_DAT
	gpio_set_func(GPIO_PD4, AS_I2S);		//I2S_DAC_DAT
	gpio_set_input_en(GPIO_PD3, 1);

	audio_set_i2s_clk(0x81,0x18);

	reg_dfifo_dec_ratio = 0;

	reg_clk_en2 |= FLD_CLK2_DFIFO_EN; //enable dfifo clock, this will be initialed in cpu_wakeup_int()

	//2. amic input, mono mode, enable decimation filter
	reg_dfifo_ain = 	  MASK_VAL( FLD_AUD_DMIC0_DATA_IN_RISING_EDGE,	AUDIO_DMIC_DATA_IN_RISING_EDGE,\
									FLD_AUD_INPUT_SELECT, 				AUDIO_INPUT_I2S, \
									FLD_AUD_INPUT_MONO_MODE, 			1, \
									FLD_AUD_DECIMATION_FILTER_BYPASS, 	1, \
									FLD_AUD_DMIC_RISING_EDGE_BYPASS  ,	0, \
									FLD_AUD_DMIC_FALLING_EDGE_BYPASS ,	0);

	reg_audio_ctrl |= FLD_AUDIO_I2S_INTERFACE_EN|FLD_AUDIO_I2S_RECORDER_EN;

	////////////////////////////// ALC HPF LPF setting /////////////////////////////////
	//enable hpf, enable lpf, anable alc, disable double_down_sampling
	reg_aud_alc_hpf_lpf_ctrl =   MASK_VAL( FLD_AUD_IN_HPF_SFT,  0x0b,   //different pcb may set different value.
										   FLD_AUD_IN_HPF_BYPASS, 1, \
										   FLD_AUD_IN_ALC_BYPASS, 1, \
										   FLD_AUD_IN_LPF_BYPASS, 1, \
										   FLD_DOUBLE_DOWN_SAMPLING_ON, 1);

	reg_dfifo_dec_ratio = 0x00;


	reg_dfifo_mode = FLD_AUD_DFIFO0_IN | FLD_AUD_DFIFO0_OUT;
}


/**
 *
 * @brief	   	i2s setting function, enable or disable the i2s output, configure i2s output paramaters
 * @param[in] 	InType		- select audio input type including amic ,dmic ,i2s and usb
 * @param[in] 	Audio_Rate 	- select audio rate, which will decide on which adc sampling rate and relative decimation configuration will be chosen .
 *
 * @return	  	none
 */
void audio_set_i2s_output(AudioInput_Typedef InType,AudioRate_Typedef Audio_Rate)
{
	//config dmic clock for 12Mhz to offer the MCLK of CORDEC
	gpio_set_func(GPIO_PA1, AS_DMIC);		//XTI/MCLK from DMIC clk
	audio_set_dmic_clk(0x81,0x4);

	//config i2s clock for 1Mhz to offer the clk of CORDEC
	gpio_set_func(GPIO_PD7, AS_I2S);		//I2S_BCK
	gpio_set_func(GPIO_PD2, AS_I2S);		//I2S_ADC_LRC  I2S_DAC_LRC
	gpio_set_func(GPIO_PD3, AS_I2S);		//I2S_ADC_DAT
	gpio_set_func(GPIO_PD4, AS_I2S);		//I2S_DAC_DAT
	gpio_set_input_en(GPIO_PD3, 1);
	audio_set_i2s_clk(1,0x18);

	reg_pwm_ctrl = MASK_VAL( 	FLD_PWM_MULTIPLY2,			0,\
								FLD_PWM_ENABLE,				0,\
								FLD_LINER_INTERPOLATE_EN,	1,\
								FLD_LEFT_SHAPING_EN,		0,\
								FLD_RIGTH_SHAPING_EN,		0);


	if(InType==AMIC)
	{
		reg_ascl_tune = 0x80000001;
	}
	else
	{
		reg_ascl_tune = DSDM_Rate_Matching[Audio_Rate];
	}

	//config player mode
	if(InType == I2S_IN)
	{
		reg_audio_ctrl = (FLD_AUDIO_MONO_MODE|FLD_AUDIO_SDM_PLAYER_EN|FLD_AUDIO_I2S_RECORDER_EN|FLD_AUDIO_I2S_INTERFACE_EN);
	}
	else if(InType == USB_IN)
	{
		reg_audio_ctrl = (FLD_AUDIO_MONO_MODE|FLD_AUDIO_SDM_PLAYER_EN|FLD_AUDIO_ISO_PLAYER_EN);
	}
	else
	{
		reg_audio_ctrl = (FLD_AUDIO_MONO_MODE|FLD_AUDIO_I2S_INTERFACE_EN|FLD_AUDIO_I2S_PLAYER_EN);
	}

	reg_dfifo_mode |= FLD_AUD_DFIFO0_OUT;
}

/**
 * @brief     This function servers to set USB input/output.
 * @param[in] none.
 * @return    none.
 */
void audio_set_usb_output(void)
{
	WRITE_REG8(0xb10,0xf9);
}

/**
 *	@brief		reg0x30[1:0] 2 bits for fine tuning, divider for slow down sample rate
 *	@param[in]	fine_tune - unsigned char fine_tune,range from 0 to 3
 *	@return	    none
 */
void audio_finetune_sample_rate(unsigned char fine_tune)
{

}

/**
 *  @brief      tune decimation shift .i.e register 0xb04 in datasheet.
 *  @param[in]  deci_shift - range from 0 to 5.
 *  @return     none
 */
unsigned char audio_tune_deci_shift(unsigned char deci_shift)
{

}

/**
 *   @brief       tune the HPF shift .i.e register 0xb05 in datasheet.
 *   @param[in]   hpf_shift - range from 0 to 0x0f
 *   @return      none
 */
 unsigned char audio_tune_hpf_shift(unsigned char hpf_shift)
 {

 }
/**
 *	@brief	    set audio volume level
 *	@param[in]	input_out_sel - select the tune channel, '1' tune ALC volume; '0' tune SDM output volume
 *	@param[in]	volume_level - volume level
 *	@return	    none
 */
void audio_set_volume(unsigned char input_out_sel, unsigned char volume_level)
{

}

/**
*
* 	@brief		automatically gradual change volume
* 	@param[in]	vol_step - volume change step, the high part is decrease step while the low part is increase step
*			    gradual_interval - volume increase interval
* 	@return		none
*/
void audio_set_volume_step(unsigned char vol_step,unsigned short gradual_interval)
{

}
