/********************************************************************************************************
 * @file     adc.h
 *
 * @brief    This is the AOA_AOD driver header file for TLSR8258
 *
 * @author	 yang.ye@telink-semi.com;
 * @date     September 20, 2019
 *
 * @par      Copyright (c) 2018, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *           The information contained herein is confidential property of Telink
 *           Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *           of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *           Co., Ltd. and the licensee or the terms described here-in. This heading
 *           MUST NOT be removed from this file.
 *
 *           Licensees are granted free, non-transferable use of the information in this
 *           file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 * @par      History:
 * 			 1.initial release(DEC. 26 2018)
 *
 * @version  A001
 *
 *******************************************************************************************************/

#pragma once

#include "bsp.h"
#include "analog.h"
#include "register.h"
#include "gpio_8258.h"
#include "printf.h"

#define RF_REAL_FREQ			2460
#define IQ_NUM                  45
#define SLOT_TIME				2
#define Lamida                  3*10000*1000/(RF_REAL_FREQ*100 + 25)
#define sign_mark				-1
#define Radius					75
#define XY_TABLE_NUMBER			45
#define Z_TABLE_NUMBER			31
#define AMP_SIZE				32

#define SRAM_BOTTOM				0x840000
#define SRAM_TOP				0x84FFFF

typedef struct IQ_VALUE
{
	int real_part;
	int imag_part;
}IQ_Value;

typedef struct IQ_CB
{
	IQ_Value IQ[100];
	int number;
}IQ_cb;

typedef struct FUNC_CB
{
	int* 	int_ptr1;
	int* 	int_ptr2;
	char*   char_ptr1;
	char*	char_ptr2;
	int		int1;
	int		int2;
	char	char1;
	char	char2;
	char	char3;
	char	char4;
}Func_CB;

char tan_look_table(unsigned int tan);
char sin_look_table(unsigned int sin);
int cos_calculate(int cos_val);
void demodulation(int* real_ptr,int* imag_ptr,unsigned char num);
void conj(IQ_cb iq,IQ_cb conj_iq,unsigned char number);
int  calc_phase(int real, int imag);
void dot_product(IQ_cb Table1,IQ_cb Table2,unsigned char fst_num,unsigned char scd_num);	//,IQ_Value rst_tb
int  phase_combine(int* x_ptr,int osr);
int  angle_trans(int x);	//input is 1024 times
char unwrap(int* ptr1,int* ptr2);
void delate_average(int* ptr);
char get_input_angle(unsigned char *ptr_packet);
unsigned int get_input_angle_for_polygon(unsigned char *ptr_packet);
unsigned int get_input_angle_for_polygon_with_z(unsigned char *ptr_packet);
void get_raw_data(unsigned char *data_table,unsigned char *ptr_packet,unsigned int number);
void bcopy(register char * src, register char * dest, int len);
void bbcopy(register char * src, register char * dest, int len);
void * memcpy(void * out, const void * in, unsigned int length);
void * memset(void * dest, int val, unsigned int len);
void init_lookup_table(void);
unsigned char wrap(Func_CB func);
unsigned char circshift(Func_CB func);
unsigned char trans_uchar_to_int(unsigned char* src_tb,int* rst_tb,unsigned int number);

