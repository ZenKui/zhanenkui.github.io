/********************************************************************************************************
 * @file     usb.h
 *
 * @brief    This is the header file for TLSR8258
 *
 * @author	 junwei.lu@telink-semi.com;
 * @date     May 8, 2018
 *
 * @par      Copyright (c) 2018, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *           The information contained herein is confidential property of Telink
 *           Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *           of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *           Co., Ltd. and the licensee or the terms described here-in. This heading
 *           MUST NOT be removed from this file.
 *
 *           Licensees are granted free, non-transferable use of the information in this
 *           file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 * @par      History:
 * 			 1.initial release(DEC. 26 2018)
 *
 * @version  A001
 *
 *******************************************************************************************************/

#ifndef USB_H_
#define USB_H_

#include "usbhw.h"
#include "usbhw_i.h"
#include "printf.h"
#include "usb_desc.h"

extern unsigned char usb_g_config;

#if(USB_MODE_CDC_EN)
extern unsigned char usb_cdc_data[USB_CDC_TX_RX_EPSIZE];
extern unsigned short usb_cdc_data_len;
#endif

#if(USB_MODE_MICPHONE_EN||USB_MODE_SPEAKER_EN)
extern unsigned char usb_audio_mic_cnt;
extern unsigned char usb_audio_speaker_cnt;
#endif

enum{
	USB_EDP_SETUP_IRQ_REQ = 0,
	USB_EDP_DATA_IRQ_REQ,
};

/**
 * @brief		This function serves to enable manual interrupt
 * @param[in] 	none
 * @return 		none
 */
void usb_irq_init(void);

/**
 * @brief		This function serves to handle interrupt request
 * @param[in] 	data_request - DATA_REQ and SETUP_REQ
 * @return 		none
 */
void usb_handle_request_process(unsigned char data_request);

/**
 * @brief		This function serves to handle SETUP process
 * @param[in] 	none
 * @return 		none
 */
void usb_handle_ctl_ep_setup();

/**
 * @brief		This function serves to handle DATA process
 * @param[in] 	none
 * @return 		none
 */
void usb_handle_ctl_ep_data(void);

/**
 * @brief		This function serves to handle STATUS process
 * @param[in] 	none
 * @return 		none
 */
void usb_handle_ctl_ep_status();

/**
 * @brief		This function serves to handle interrupt request from USB host
 * @param[in] 	none
 * @return 		none
 */
void usb_handle_irq_process(void);

#if USB_MODE_CDC_EN
/**
 * @brief		This function serves to send data to USB host in CDC device
 * @param[in] 	data_ptr -  the pointer of data, which need to be sent.
 * @param[in] 	data_len -  the length of data, which need to be sent.
 * @return 		none
 */
void usb_cdc_tx_data_to_host(unsigned char * data_ptr, unsigned short data_len);
#endif

#if(USB_MODE_KEYBOARD_EN)
/**
 * @brief		This function serves to send HID report of Keyboard
 * @param[in] 	none
 * @return 		none
 */
int usb_keyboard_hid_report(unsigned char *data);
#endif

#if USB_MODE_MOUSE_EN
/**
 * @brief		This function serves to send HID report of Mouse
 * @param[in] 	none
 * @return 		none
 */
int usb_mouse_hid_report(unsigned char * p);
#endif

#endif /* USB_H_ */

/** \defgroup GP16  USB Examples
 *
 *  @{
 */
/*! \page usb Table of Contents
	- [API-USB-CASE1:MOUSE DEVICE](#MOUSE_DEVICE)
	- [API-USB-CASE2:KEYBOARD DEVICE](#KEYBOARD_DEVICE)
	- [API-USB-CASE3:CDC DEVICE](#CDC_DEVICE)
	- [API-USB-CASE4:MICROPHONE DEVICE](#MICROPHONE_DEVICE)
	- [API-USB-CASE5:SPEAKER DEVICE](#SPEAKER_DEVICE)
\n	

<h1 id=MOUSE_DEVICE> API-USB-CASE1:MOUSE DEVICE </h1>

| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | none ||| interrupt handle function | 2019-1-10 |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | usb_set_pin_en() || open the DP and DM of USB and enable 1.5k internal pull-up resistor | ^ |
| ^ | ^ | usb_irq_init() ||  enable manual interrupt | ^ |
| ^ | ^ | irq_enable() || enable global interrupt | ^ |
| ^ | ^ | gpio_set_func() <br>  gpio_set_input_en() <br> gpio_set_output_en() <br> gpio_set_up_down_resistor() | gpio_set_func(GPIO_PD1, AS_GPIO) <br>  gpio_set_input_en(GPIO_PD1,1) <br> gpio_set_output_en(GPIO_PD1,0) <br> gpio_set_up_down_resistor(GPIO_PD1, PM_PIN_PULLUP_10K) | set pin for simulate pressing the left or right key of Mouse | ^ |
| ^ | ^ | ^ | gpio_set_func(GPIO_PD2, AS_GPIO) <br>  gpio_set_input_en(GPIO_PD2,1) <br> gpio_set_output_en(GPIO_PD2,0) <br> gpio_set_up_down_resistor(GPIO_PD2, PM_PIN_PULLUP_10K) | set pin for simulate releasing the left or right key of Mouse | ^ |
| ^ | main_loop() | usb_handle_irq_process() || handle with USB interrupt  | ^ |
| ^ | ^ | refer to [Driver Demo](#) || check whether key is pressed | ^ |
| ^ | ^ | usb_mouse_hid_report() | usb_mouse_hid_report(mouse) | send key value of Mouse to USB host | ^ |

\n
Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}
unsigned char  mouse[4];
~~~~~~~~~~~~~~~~~~~~~~~~~~~
	

<h1 id=KEYBOARD_DEVICE> API-USB-CASE2:KEYBOARD DEVICE </h1>

| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | none ||| interrupt handle function | 2019-1-10 |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | usb_set_pin_en() || open the DP and DM of USB and enable 1.5k internal pull-up resistor | ^ |
| ^ | ^ | usb_irq_init() ||  enable manual interrupt | ^ |
| ^ | ^ | usbhw_data_ep_ack() | usbhw_data_ep_ack(USB_EDP_KEYBOARD_OUT) | set ep3 BUSY(BUSY same as ACK) bit as 1 means output endpoint buffer can receive data from USB host | ^ |
| ^ | ^ | irq_enable() || enable global interrupt | ^ |
| ^ | ^ | gpio_set_func() <br>  gpio_set_input_en() <br> gpio_set_output_en() <br> gpio_set_up_down_resistor() | gpio_set_func(GPIO_PD1, AS_GPIO) <br>  gpio_set_input_en(GPIO_PD1,1) <br> gpio_set_output_en(GPIO_PD1,0) <br> gpio_set_up_down_resistor(GPIO_PD1, PM_PIN_PULLUP_10K) | set pin for simulate pressing the left or right key of Mouse | ^ |
| ^ | ^ | ^ | gpio_set_func(GPIO_PD2, AS_GPIO) <br>  gpio_set_input_en(GPIO_PD2,1) <br> gpio_set_output_en(GPIO_PD2,0) <br> gpio_set_up_down_resistor(GPIO_PD2, PM_PIN_PULLUP_10K) | set pin for simulate releasing the left or right key of Mouse | ^ |
| ^ | main_loop() | usb_handle_irq_process() || handle with USB interrupt  | ^ |
| ^ | ^ | refer to [Driver Demo](#) || check whether key is pressed | ^ |
| ^ | ^ | usb_keyboard_hid_report() | usb_keyboard_hid_report(kb_data) | send key value of Keyboard to USB host | ^ |

\n
Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}
unsigned char kb_data[8];
~~~~~~~~~~~~~~~~~~~~~~~~~~~
	
<h1 id=CDC_DEVICE> API-USB-CASE3:CDC DEVICE </h1>
| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | none ||| interrupt handle function | 2019-1-10 |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | usb_set_pin_en() || open the DP and DM of USB and enable 1.5k internal pull-up resistor | ^ |
| ^ | ^ | usb_irq_init() ||  enable manual interrupt | ^ |
| ^ | ^ | usbhw_data_ep_ack() | usbhw_data_ep_ack(USB_EDP_CDC_OUT) | set ep5 BUSY(BUSY same as ACK) bit as 1 means output endpoint buffer can receive data from USB host | ^ |
| ^ | ^ | irq_enable() || enable global interrupt | ^ |
| ^ | main_loop() | usb_handle_irq_process() || handle with USB interrupt  | ^ |
| ^ | ^ | refer to [Driver Demo](#) || check whether data is reveived | ^ |
| ^ | ^ | usb_cdc_tx_data_to_host() | usb_cdc_tx_data_to_host(usb_cdc_data,usb_cdc_data_len) | send data from USB host to USB host | ^ |

\n
Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}
#define USB_CDC_TX_RX_EPSIZE               	64
unsigned char usb_cdc_data[USB_CDC_TX_RX_EPSIZE];
unsigned short usb_cdc_data_len;
unsigned int usb_cdc_tx_cnt;

//  Line Coding Structure is as follows:
//  Offset | Field       | Size | Value  | Description
//  0      | dwDTERate   |   4  | Number | Data terminal rate, in bits per second
//  4      | bCharFormat |   1  | Number | Stop bits: 0-1/1-1.5/2-2.
//  5      | bParityType |   1  | Number | Parity:0-None/1-Odd/2-Even/3-Mark/4-Space
//  6      | bDataBits   |   1  | Number | Data bits (5, 6, 7, 8 or 16).

unsigned char LineCoding[7]={0x00,0xC2,0x01,0x00,0x00,0x00,0x08};
~~~~~~~~~~~~~~~~~~~~~~~~~~~

<h1 id=MICROPHONE_DEVICE> API-USB-CASE4:MICROPHONE DEVICE </h1>

&nbsp;&nbsp;&nbsp;&nbsp;refer to [API-AUDIO-CASE1:AMIC To USB](group___g_p3.html#AMIC_To_USB)

<h1 id=SPEAKER_DEVICE> API-USB-CASE5:SPEAKER DEVICE </h1>

&nbsp;&nbsp;&nbsp;&nbsp;refer to [API-AUDIO-CASE9:USB To SDM](group___g_p3.html#USB_To_SDM)

<h1> History Record </h1>

| Date | Description | Author |
| :--- | :---------- | :----- |
| 2019-1-10 | initial release | SP/YY/LJW |

*/

 /** @}*/ //end of GP16
