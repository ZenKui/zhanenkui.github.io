/********************************************************************************************************
 * @file     s7816.h 
 *
 * @brief    This is the header file for TLSR8258
 *
 * @author	 junwei.lu@telink-semi.com;
 * @date     May 8, 2018
 *
 * @par      Copyright (c) 2018, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *           The information contained herein is confidential property of Telink
 *           Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *           of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *           Co., Ltd. and the licensee or the terms described here-in. This heading
 *           MUST NOT be removed from this file.
 *
 *           Licensees are granted free, non-transferable use of the information in this
 *           file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 * @par      History:
 * 			 1.initial release(DEC. 26 2018)
 *
 * @version  A001
 *
 *******************************************************************************************************/


#ifndef S7816_H_
#define S7816_H_

#include "gpio.h"

/**
 *  @brief  Define 7816 TRx pin
 */
typedef enum{
	S7816_TRX_D0,
	S7816_TRX_D3,
	S7816_TRX_D7,
}S7816_TRx_PinDef;

typedef enum {
	S7816_TX,
	S7816_RX,
}S7816_Half_Duplex_ModeDef;

/**
 * @brief      	This function is used to initiate 7816 module of MCU
 * @param[in]  	Div	-set the divider of clock of 7816 module:
 * 				7816clk = sysclk/(0x7b[6:4]*2),	0x7b[7]:enable 7816clk
 * 				7816clk:  0x40-2Mhz   0x20-4Mhz
 * 				baudrate: 0x40-16194  0x20-32388
 * @return     	none
 */
extern void s7816_set_clk(unsigned char Div);

/**
 * @brief      	This function is used to set address and size of buffer 7816 module of MCU
 * @param[in]  	*RecvAddr		-set the address of buffer to receive data
 * @param[in]  	RecvBufLen		-set the length of buffer to receive data
 * @return     	none
 */
extern void s7816_set_rx_buf(unsigned short *RecvAddr, unsigned short RecvBufLen);

/**
 * @brief      	This function is used to initiate 7816 module of MCU
 * @param[in]  	Pin_7816_TRX	-select the I/O 	pin of 7816 module
 * @param[in]	Pin_7816_RST	-select the RST 	pin of 7816 module
 * @param[in]	Pin_7816_VCC	-select the VCC 	pin of 7816 module
 * @return     	none
 */
extern void s7816_set_pin(S7816_TRx_PinDef Pin_7816_TRX);


/**
 * @brief      	This function is used to send data to ID card,after succeeding in getting ATR
 * @param[in]  	*TransAddr	- data is waitting to send
 * @return     	none
 */
extern unsigned char s7816_dma_send(unsigned char *TransAddr);

/**
 * @brief      	This function is used to transform half duplex mode of 7816
 * @param[in]  	mode	- half_duplex_mode_TX/RX is transformed by setting 0x9b[5]
 * 						0x9b[5]=1:half_duplex_mode_RX;0x9b[5]=0:half_duplex_mode_TX
 * @return     	none
 */
extern void s7816_set_half_duplex(S7816_Half_Duplex_ModeDef mode);


#endif /* S7816_H_ */


/** \defgroup GP12  S7816 Examples
 *    
 *  @{	
 */
/*! \page S7816 Table of Contents
	- [API-S7816-CASE1:S7816 TX MODE](#S7816_TX_MODE)
	- [API-S7816-CASE2:S7816 RX MODE](#S7816_RX_MODE)
	
<h1 id=S7816_TX_MODE> API-S7816-CASE1:S7816 TX MODE</h1>

| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | if(dma_get_irq_status() & FLD_DMA_CHN_UART_TX == FLD_DMA_CHN_UART_TX) ||| Determine whether TX interrupt flag is right in DMA MODE | 2019-1-10 |
| ^ | >dma_clr_irq_status()| dma_clr_irq_status(FLD_DMA_CHN_UART_TX) || Clear UART TX interrupt flag | ^ |
| ^ | >uart_dmairq_tx_cnt++ ||| Interrupt processing function | ^ |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | s7816_set_clk() |s7816_set_clk(0x20) | Set the divider of clock of 7816 module| ^ |
| ^ | ^ | s7816_set_rx_buf() | s7816_set_rx_buf((unsigned short *)&recvBuff,sizeof(recvBuff))| Set address and size of buffer for 7816 module of MCU | ^ |
| ^ | ^ | s7816_set_pin() | s7816_set_pin(S7816_TRX_D7)| Initiate 7816 module pin | ^ |
| ^ | ^ | uart_reset() || Reset uart digital registers from 0x90 ~ 0x9f  | ^ |
| ^ | ^ | uart_init_baudrate() | uart_init_baudrate(9600,CLOCK_SYS_CLOCK_HZ,PARITY_NONE, STOP_BIT_ONE) | UART module initialization | ^ |
| ^ | ^ | uart_dma_en() | uart_dma_en(1, 1)|Enable UART DMA function | ^ |
| ^ | ^ | irq_set_mask() | irq_set_mask(FLD_IRQ_DMA_EN)|Enable DMA irq | ^ |
| ^ | ^ | dma_set_irq_en() | dma_set_irq_en(FLD_DMA_CHN_UART_RX &Iota; FLD_DMA_CHN_UART_TX, 1) | EnableUart Rx/Tx dma irq  | ^ |
| ^ | ^ | uart_irq_en() |uart_irq_en(0, 0) | Disable uart RX/TX irq | ^ |
| ^ | ^ | irq_enable() || enable global interrupt | ^ |
| ^ | ^ | s7816_set_half_duplex() | s7816_set_half_duplex(S7816_TX)|Transform half duplex mode of 7816 | ^ |
| ^ | main_loop()|s7816_dma_send() | s7816_dma_send(trans_buff)| Send data| ^ |

\n
Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}

volatile __attribute__((aligned(4))) unsigned char trans_buff[16] = {0x05,0x00,0x00,0x00,0xFF,0x10,0x12,0xFD,0x00};

~~~~~~~~~~~~~~~~~~~~~~~~~~~



<h1 id=S7816_RX_MODE> API-S7816-CASE2:S7816 RX MODE</h1>

| Function | Sub-Function | APIs || Description | Update Status |
| :------- | :----------- | :---------- | :---------- |:---------- | :------------ |
| irq_handler() | if(dma_get_irq_status() & FLD_DMA_CHN_UART_RX == FLD_DMA_CHN_UART_RX) ||| Determine whether  RX interrupt flag is right in DMA MODE | 2019-1-10 |
| ^ | >dma_clr_irq_status()| dma_clr_irq_status(FLD_DMA_CHN_UART_RX)|| Clear UART RX interrupt flag | ^ |
| ^ | >uart_dmairq_rx_cnt++ ||| Interrupt processing function | ^ |
| main() | system_init() ||| CPU initialization function [**Mandatory**] | ^ |
| ^ | clock_init() | clock_init(SYS_CLK_24M_XTAL) || Clock initialization function, System Clock is 24M RC by default [**optional**] | ^ |
| ^ | rf_mode_init() | rf_mode_init(RF_MODE_BLE_1M) || RF mode initialization [**optional**] | ^ |
| ^ | gpio_init() ||| GPIO initialization: set the initialization status of all GPIOs [**optional**] | ^ |
| ^ | user_init() | s7816_set_clk()| s7816_set_clk(0x20) | Set the divider of clock of 7816 module| ^ |
| ^ | ^ | s7816_set_rx_buf() | s7816_set_rx_buf((unsigned short *)&recvBuff,sizeof(recvBuff))| Set address and size of buffer for 7816 module of MCU | ^ |
| ^ | ^ | s7816_set_pin() | s7816_set_pin(S7816_TRX_D7)| Initiate 7816 module pin | ^ |
| ^ | ^ | uart_reset() || Reset uart digital registers from 0x90 ~ 0x9f  | ^ |
| ^ | ^ | uart_init_baudrate() | uart_init_baudrate(9600,CLOCK_SYS_CLOCK_HZ,PARITY_NONE, STOP_BIT_ONE)| UART module initialization | ^ |
| ^ | ^ | uart_dma_en() | uart_dma_en(1, 1)|Enable UART DMA function | ^ |
| ^ | ^ | irq_set_mask() | irq_set_mask(FLD_IRQ_DMA_EN)|Enable DMA irq  | ^ |
| ^ | ^ | dma_set_irq_en() | dma_set_irq_en(FLD_DMA_CHN_UART_RX &Iota; FLD_DMA_CHN_UART_TX, 1) | Enable Uart Rx/Tx dma irq | ^ |
| ^ | ^ | uart_irq_en()| uart_irq_en(0, 0) | Disable uart RX/TX irq | ^ |
| ^ | ^ | irq_enable()|| enable global interrupt | ^ |
| ^ | ^ | s7816_set_half_duplex()| s7816_set_half_duplex(S7816_RX) | Transform half duplex mode of 7816 | ^ |
| ^ | main_loop() | None || Main program loop | ^ |

\n
Variables above are defined as below
~~~~~~~~~~~~~~~~~~~~~~~~~~~{.c}

volatile __attribute__((aligned(4))) unsigned char recvBuff[48] = {0x00};

~~~~~~~~~~~~~~~~~~~~~~~~~~~

<h1> History Record </h1>

| Date | Description | Author |
| :--- | :---------- | :----- |
| 2019-1-10 | initial release | SP/LJW |

@}*/ //end of GP12


