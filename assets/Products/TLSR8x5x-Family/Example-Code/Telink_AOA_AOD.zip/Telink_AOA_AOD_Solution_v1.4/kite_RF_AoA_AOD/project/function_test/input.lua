print("LUA Version: ".._VERSION)
print("lua begin:")
print "wait input:"
a = tl_input_get()
while(a=="NULL")
do
   a = tl_input_get()
  
end
print(a)
print "wait input:"
a = tl_input_get()
while(a=="NULL")
do
   a = tl_input_get()
  
end
print(a)
tl_stop()
print "-------end of input test ---------"